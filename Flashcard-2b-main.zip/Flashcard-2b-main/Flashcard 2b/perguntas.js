criaCartao(
    'História',
    'Quem descobriu o Brasil?',
    'Pedro Alvares Cabral descobriu o Brasil'
)

criaCartao(
    'Esportes',
    'Quem é o atual lider da temporada da Fórmula 1',
    'O lider é Max Verstappen'
)
